/**
 * Created by Kamran on 29-Nov-15.
 */

myApp.controller('SuccessController',['$scope',function($scope){
    $scope.message='Success!!!';
}])
